#!/bin/sh

/etc/init.d/upsmon stop
esxcli software vib remove -f -n upsmon

esxcfg-advcfg -L NutUpsName
esxcfg-advcfg -L NutUser
esxcfg-advcfg -L NutPassword
esxcfg-advcfg -L NutFinalDelay
esxcfg-advcfg -L NutMailTo
esxcfg-advcfg -L NutSendMail
