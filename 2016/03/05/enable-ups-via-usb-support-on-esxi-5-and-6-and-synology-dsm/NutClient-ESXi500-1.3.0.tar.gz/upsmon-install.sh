#!/bin/sh

DIRNAME="`pwd`"
esxcfg-advcfg -A NutUpsName -T string -E 'NUT remote ups name (eg: upsname@nutserver) use space as a separator for multiple upses' -F upsname@nutserver
esxcfg-advcfg -A NutUser -T string -E 'NUT username to connect to remote ups' -F upsuser
esxcfg-advcfg -A NutPassword -T string -E 'NUT password to connect to remote ups' -F upspassword
esxcfg-advcfg -A NutFinalDelay -T int -E 'NUT seconds to wait on low battery event before shutting down' -N 0 -M 3600 -F 5
esxcfg-advcfg -A NutMailTo -T string -E 'NUT send mail notification to this address' -F root@domain
esxcfg-advcfg -A NutSendMail -T int -E 'NUT send mail notification (1=yes 0=no)' -N 0 -M 1 -F 0 
esxcli software vib install -f -v "${DIRNAME}/upsmon-2.7.2-1.3.0vmw.500.x86_64.vib"
